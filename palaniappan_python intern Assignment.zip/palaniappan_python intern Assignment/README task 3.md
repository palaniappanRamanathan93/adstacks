
Task 3

Python script(s) for setting up and managing the virtual Android system.

Prerequisites:

Python 3.7+
QEMU ( installed and configured )
Android Emulator Plugin ( installed and configured )
APK file for the sample app

Python Script:

import subprocess
import os
import logging

logging.basicConfig(filename='virtual_android.log', level=logging.INFO)

def create_virtual_environment():
    
    qemu_process = subprocess.Popen(['qemu-system-x86_64', '-m', '2048', '-vnc', ':0', '-bios', 'OVMF.fd'])

    return qemu_process

def launch_virtual_system(qemu_process):

    qemu_process.wait(timeout=60)

    
    emulator_process = subprocess.Popen(['emulator', '-avd', 'Android_Accelerated_x86_Oreo'])


    emulator_process.wait(timeout=60)

def install_app(apk_file):
    
    subprocess.run(['adb', 'install', apk_file])

def get_system_info():
    
    os_version = subprocess.check_output(['adb', 'shell', 'getprop', 'ro.build.version.release']).decode('utf-8').strip()

    logging.info(f'OS Version: {os_version}')

    
    device_model = subprocess.check_output(['adb', 'shell', 'getprop', 'ro.product.model']).decode('utf-8').strip()

    logging.info(f'Device Model: {device_model}')

    
    available_memory = subprocess.check_output(['adb', 'shell', 'free', '-m']).decode('utf-8').strip()
    logging.info(f'Available Memory: {available_memory}')

if __name__ == '__main__':
    
    qemu_process = create_virtual_environment()

    
    launch_virtual_system(qemu_process)

    
    install_app('sample_app.apk')


    get_system_info()


Code Expalanation:

Importing Libraries:

The code starts by importing the necessary libraries:

subprocess: for running external commands and processes

os: for interacting with the operating system

logging: for logging events and information
Setting up Logging

The code sets up logging to write events and information to a file named virtual_android.log. The logging level is set to INFO, which means that only informational messages and above (e.g., warnings, errors) will be logged.

Defining Functions:

The code defines four functions:
1. create_virtual_environment():

This function creates a virtual Android environment using QEMU. It starts a QEMU process with the following options:

-m 2048: allocates 2048MB of memory

-vnc :0: enables VNC (Virtual Network Computing) on port 0

-bios OVMF.fd: specifies the BIOS file to use
The function returns the QEMU process object.

2. launch_virtual_system(qemu_process)

This function launches the virtual system and displays a terminal or GUI interface. It waits for the QEMU process to start (with a timeout of 60 seconds) and then starts the Android Emulator with the following options:

-avd Android_Accelerated_x86_Oreo: specifies the Android Virtual Device (AVD) to use

The function waits for the emulator to start (with a timeout of 60 seconds).

3. install_app(apk_file)

This function installs a sample app into the virtual system using ADB (Android Debug Bridge). It takes the APK file path as an argument and runs the adb install command to install the app.

4. get_system_info()

This function retrieves and logs system information. It uses ADB to execute shell commands and retrieve the following information:

OS version
Device model
Available memory

The function logs the retrieved information using the logging.info() function.

Main Program

The main program creates a virtual environment, launches the virtual system, installs a sample app, and retrieves and logs system information. It uses the functions defined above to perform these tasks.

Example Use Case
To use this code, save it to a file (e.g., virtual_android.py) and run it using Python (e.g., python virtual_android.py). Make sure you have QEMU, Android Emulator, and ADB installed and configured on your system. Also, replace sample_app.apk with the path to your own APK file.


