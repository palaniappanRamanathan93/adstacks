
ADSTACKS MEDIA

Task 2

Database Schema:

CREATE TABLE apps (
    id SERIAL PRIMARY KEY,
    app_name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT
)

CREATE INDEX idx_app_name ON apps (app_name)

Code Explanation:

Table Creation:

CREATE TABLE apps: Creates a new table named "apps".

id SERIAL PRIMARY KEY:

id: The column name for the unique identifier of each app.

SERIAL: Automatically assigns a unique integer value to each new row.

PRIMARY KEY: Designates the id column as the primary key, ensuring uniqueness and indexing.

app_name VARCHAR(255) NOT NULL:

app_name: The column name for the app's name.

VARCHAR(255): Specifies a variable-length string type with a maximum length of 255 characters.

NOT NULL: Ensures that the app_name column cannot be left empty.

version VARCHAR(50) NOT NULL: Similar to app_name, but with a maximum length of 50 characters for the app's version.

description TEXT: Stores the app's description as a text type, which can accommodate longer strings.

Index Creation:

CREATE INDEX: Creates a new index on the specified table and column.

idx_app_name: The name of the index being created.

ON apps (app_name): Specifies the table (apps) and column (app_name) to be indexed.


The purpose of creating an index on the app_name column is to improve query performance when filtering or searching by app name. Indexing allows the database to quickly locate specific data, reducing the time it takes to execute queries.

Sample Data:

INSERT INTO apps (app_name, version, description)
VALUES
    ('My App', '1.0.0', 'This is my first app'),
    ('Your App', '2.0.0', 'This is your second app'),
    ('Our App', '3.0.0', 'This is our third app')

Code Explanation 

Inserting Data into the Table:

INSERT INTO apps: Specifies the table (apps) where the data will be inserted.

(app_name, version, description): Lists the columns in the apps table where the data will be inserted. By specifying the columns, you can control the order and selection of data.

VALUES: Indicates that the following values will be inserted into the specified columns.

The code then lists three sets of values, each representing a new row to be inserted:

('My App', '1.0.0', 'This is my first app'):

My App: The value for the app_name column.
1.0.0: The value for the version column.
This is my first app: The value for the description column.

Similarly, the next two sets of values represent the second and third apps to be inserted.

Key Points

The id column is not explicitly specified in the INSERT statement. Since it's defined as SERIAL, PostgreSQL will automatically assign a unique integer value to each new row.

The order of the values must match the order of the columns specified in the INSERT statement.

Using INSERT INTO ... VALUES allows you to insert multiple rows at once, making it more efficient than executing separate INSERT statements for each row.





