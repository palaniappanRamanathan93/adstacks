
Task 4

Android Virtual System Server Connection Script:

This Python script establishes a connection with a backend server, sends mock data from a virtual Android system, and logs the server's response.

Script:

import requests
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


device_id = "1234567890"

system_info = {
    "os_version": "Android 11",
    "device_model": "Pixel 4",
    "manufacturer": "Google"
}


server_url = "http://example.com/api/v1/device-data"

def send_data_to_server(device_id, system_info):

    payload = json.dumps({
        "device_id": device_id,
        "system_info": system_info
    })
    
    
    headers = {
        "Content-Type": "application/json"
    }
    
    
    response = requests.post(server_url, data=payload, headers=headers)
    
    return response

def main():
    
    logger.info(f"Server response: {response.text}")

if __name__ == "__main__":

    main()

Code Explanation:


Here's a breakdown of the code:
Importing Libraries:

Python
import requests
import json
import logging

The code starts by importing the necessary libraries:
requests: for sending HTTP requests to the server
json: for working with JSON data
logging: for logging messages


Defining Mock Data:

Python

device_id = "1234567890"

system_info = {
    "os_version": "Android 11",
    "device_model": "Pixel 4",
    "manufacturer": "Google"
}

The code defines mock data to simulate a virtual Android system:

device_id: a unique identifier for the device
system_info: a dictionary containing system information (OS version, device model, manufacturer)


Defining the Server URL:

Python

server_url = "http://example.com/api/v1/device-data"

The code defines the URL of the backend server's API endpoint.

Defining the send_data_to_server Function:

def send_data_to_server(device_id, system_info):

    payload = json.dumps({
        "device_id": device_id,
        "system_info": system_info
    })
    

    headers = {
        "Content-Type": "application/json"
    }
    
    
    response = requests.post(server_url, data=payload, headers=headers)
    
    return response

The code defines a function send_data_to_server that:

Takes device_id and system_info as input arguments

Prepares a JSON payload containing the input data

Sets the Content-Type header to application/json

Sends a POST request to the server with the JSON payload

Returns the server's response

Defining the main Function:

Python
def main():
    
    logger.info(f"Server response: {response.text}")

The code defines a main function that:

Calls the send_data_to_server function with the mock data

Logs the server's response using the logger instance

Running the Script:

Python

if __name__ == "__main__":
    main()

The code uses the if __name__ == "__main__": guard to ensure that the main function is only executed when the script is run directly (not when it's imported as a module).














































































