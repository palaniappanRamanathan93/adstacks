
ADSTACKS MEDIA

Task 1


Api code

from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///jupyter_sql_tutorial.db"
db = SQLAlchemy(app)


class App(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_name = db.Column(db.String(100), nullable=False)
    version = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f"App('{self.app_name}', '{self.version}')"

    def to_dict(self):
        return {
            "id": self.id,
            "app_name": self.app_name,
            "version": self.version,
            "description": self.description,
        }


@app.route("/add-app", methods=["POST"])
def add_app():
    data = request.get_json()
    new_app = App(app_name=data["app_name"], version=data["version"], description=data["description"])
    db.session.add(new_app)
    db.session.commit()
    return jsonify({"message": "App added successfully"}), 201


@app.route("/get-app/<int:app_id>", methods=["GET"])
def get_app(app_id):
    app = App.query.get(app_id)
    if app is None:
        return jsonify({"message": "App not found"}), 404
    return jsonify(app.to_dict()), 200


@app.route("/delete-app/<int:app_id>", methods=["DELETE"])
def delete_app(app_id):
    app = App.query.get(app_id)
    if app is None:
        return jsonify({"message": "App not found"}), 404
    db.session.delete(app)
    db.session.commit()
    return jsonify({"message": "App deleted successfully"}), 200


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=False)
    

## Code Explanation

CODE Explanation

The provided code is a simple RESTful API built using Flask, a lightweight Python web framework, and Flask-SQLAlchemy, an ORM (Object-Relational Mapping) tool for interacting with databases. The API allows users to add, retrieve, and delete app details from a SQLite database.

Importing Libraries

The code starts by importing the necessary libraries:

Flask: The Flask web framework.
request: A Flask object that provides access to the current HTTP request.
jsonify: A Flask function that converts a Python dictionary to a JSON response.
SQLAlchemy: The Flask-SQLAlchemy library for interacting with databases.

Configuring the Flask App and Database:

A new Flask app is created with the current module name (__name__).

The SQLALCHEMY_DATABASE_URI configuration variable is set to specify the database connection. In this case, it's a SQLite database named jupyter_sql_tutorial.db.

A new instance of SQLAlchemy is created, passing the Flask app instance to it.


Defining the App Model:

A new class App is defined, which inherits from db.Model. This class represents a table in the database.

The class has four attributes:

id: A unique identifier for each app, represented by an integer primary key.
app_name, version, and description: Strings that store the app's name, version, and description, respectively. These fields are not nullable.

The __repr__ method returns a string representation of the app, which can be useful for debugging.

The to_dict method converts the app object to a dictionary, which can be easily serialized to JSON.

Defining API Endpoints
Add App Endpoint

This endpoint listens for POST requests to the /add-app path.
It retrieves the JSON data from the request using request.get_json().
A new App object is created using the data from the request.
The new app is added to the database session using db.session.add().
The changes are committed to the database using db.session.commit().
A JSON response is returned with a success message and a 201 status code.

Get App Endpoint

This endpoint listens for GET requests to the /get-app/<int:app_id> path, where <int:app_id> is a path parameter representing the app's ID.
It retrieves the app from the database using App.query.get(app_id).
If the app is not found, it returns a JSON response with a "not found" message and a 404 status code.
Otherwise, it returns a JSON response with the app's data (converted to a dictionary using app.to_dict()) and a 200 status code.

Delete App Endpoint

This endpoint listens for DELETE requests to the
































